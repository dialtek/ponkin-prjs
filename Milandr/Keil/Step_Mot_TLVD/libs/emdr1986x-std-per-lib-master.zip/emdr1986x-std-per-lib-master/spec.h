#ifndef SPEC_H
#define SPEC_H

#include "MDR1986VE8T.h"

#define _KEY_ 				0x8555AAA1

void POR_disable(void);
void KEY_reg_accs(void);


#endif //SPEC_H
